// FormControllers/handleErrorMsg.js
const handleErrorMsg = (msg) => {
  return msg;
};

export default handleErrorMsg;