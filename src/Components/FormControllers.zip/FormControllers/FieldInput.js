// FormControllers/FieldInput.js
import React from 'react';

function FieldInput({ name, methods }) {
  return (
    <input 
      {...methods.register(name)} 
      className="w-full bg-slate-500 px-3 py-2 border outline-none border-gray-300 rounded"
    />
  );
}

export default FieldInput;