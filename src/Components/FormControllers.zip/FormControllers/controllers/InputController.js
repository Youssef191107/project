// FormControllers/controllers/InputController.js
import React from 'react';
import FieldInput from '../FieldInput';
import handleErrorMsg from '../handleErrorMsg';

function InputController({ name, label, methods }) {
  return (
    <div className="mb-4 w-full">
      <label className="block text-gray-500">{label}</label>
      <FieldInput name={name} methods={methods} />
      {methods.formState.errors[name] && (
        <p className="text-red-500 text-sm mt-1">{handleErrorMsg(methods.formState.errors[name].message)}</p>
      )}
    </div>
  );
}

export default InputController;